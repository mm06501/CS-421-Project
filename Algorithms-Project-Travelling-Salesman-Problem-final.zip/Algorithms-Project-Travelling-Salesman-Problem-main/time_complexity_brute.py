import matplotlib.pyplot as plt
import time
from util import City, read_cities, path_cost
import itertools


class BruteForce:
    def __init__(self, cities):
        self.cities = cities

    def run(self):
        self.cities = min(itertools.permutations(self.cities),
                           key=lambda path: path_cost(path))
        return path_cost(self.cities)


def measure_time_complexity(data_set_sizes):
    """Measures and plots time complexity for different data set sizes."""

    time_complexity = []
    for size in data_set_sizes:
        cities = read_cities(size)
        start_time = time.time()
        brute_force = BruteForce(cities)
        brute_force.run()
        end_time = time.time()
        time_complexity.append(end_time - start_time)

    plt.plot(data_set_sizes, time_complexity, 'bo-')
    plt.xlabel("Number of Cities")
    plt.ylabel("Time (seconds)")
    plt.title("Time Complexity of Brute Force TSP Algorithm")
    plt.grid(True)
    plt.show()


if __name__ == "__main__":
    data_set_sizes = [6, 8, 10, 12]  # Adjust sizes as needed (be cautious for larger values)
    measure_time_complexity(data_set_sizes)
