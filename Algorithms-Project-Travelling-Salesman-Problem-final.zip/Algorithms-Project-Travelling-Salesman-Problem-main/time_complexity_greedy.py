import matplotlib.pyplot as plt
import time
from util import City, read_cities, path_cost


class Greedy:
    def __init__(self, cities):
        self.unvisited = cities[1:]
        self.route = [cities[0]]

    def run(self):
        while len(self.unvisited):
            idx, nearest_city = min(enumerate(self.unvisited),
                                    key=lambda item: item[1].distance(self.route[-1]))
            self.route.append(nearest_city)
            del self.unvisited[idx]
        self.route.append(self.route[0])
        self.route.pop()
        return path_cost(self.route)


def measure_time_complexity(data_set_sizes):
    """Measures and plots time complexity for different data set sizes."""

    time_complexity = []
    for size in data_set_sizes:
        cities = read_cities(size)
        start_time = time.time()
        greedy = Greedy(cities)
        greedy.run()
        end_time = time.time()
        time_complexity.append(end_time - start_time)

    plt.plot(data_set_sizes, time_complexity, 'bo-')
    plt.xlabel("Number of Cities")
    plt.ylabel("Time (seconds)")
    plt.title("Time Complexity of Greedy TSP Algorithm")
    plt.grid(True)
    plt.show()


if __name__ == "__main__":
    data_set_sizes = [ 6, 8, 10, 12, 16, 20, 30, 50, 75, 100]  # You can add more sizes here
    measure_time_complexity(data_set_sizes)
